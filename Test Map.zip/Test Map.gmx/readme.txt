This is a small map created for testing purposes. It is not made using the game's coding and must be implimented into
the actual game.

USING THE MAP
Viewing the map is quite simple. Just play it like you would any regular GameMaker work-in-progress and it runs the map.
To view descriptions of tiles, just click on the desired tile, and a description appears as a pop-up. Empty tiles do not
have descriptions.

IMPLIMENTING THE MAP (For Eidolon Six)
The technical specifics for implimenting the map into the base game will be up to you to figure out. The map has been
balanced for gameplay as well as possible without actual numerical data, and the positions of tiles should not be shifted
around, unless you have a good reason to do so.

For assigning resources, instructions can be found in the descriptions of planets. Planets described as resource-rich
should have a large number of resources, planets described as having significant resources should have a moderate amount
of resources, and planets with few or a small amount of resources should have a little bit of resources, usually not a
number worth harvesting unless desperate. For planets without descriptions pertaining to resources, assume they have
few to no resources. Since we don't have an economy/upgrade system in place, what number counts as 'not worth harvesting'
or 'rich with resources' is up to your descretion.

OTHER INFO
-Nebulas are a random addition made for the sake of world-building. They do not necessarily have to be implimented into
the final game, they are just one of the extra things that can be done if there's time. If nebulas are to be implimented,
they should be classes with a mixture of attributes from planets and empty tiles; they have resources like planets, but
structures built in them should be the structures that are constructable in empty space instead of planetary buildings.

-This map assumes the game mechanic that technological upgrades can be obtained through means other than just paying
resources to research them. Thus, planets where the player can supposedly salvage alien technology exist. For the
moment, this is purely a lore detail found in the description; it may be altered in the final game depending on whether
this mechanic is implimented or not.

-The sprites for the planets and the background image are ripped straight from the internet, and I have not checked
whether they are copyrighted or in the public domain. They should not be used in the final game. The nebula sprite is
created in Microsoft Paint and is legal for use in any manner.
